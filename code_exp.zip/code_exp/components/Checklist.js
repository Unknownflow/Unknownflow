import * as React from 'react';
import { Text, View } from 'react-native';
import { FontAwesome } from 'react-native-vector-icons';

export default function Checklist() {
  return (
    <View style={{ flex: 1, backgroundColor: 'yellow', justifyContent: 'center', alignItems: 'center'}}>
      <Text>Checklist!</Text>
    </View>
  )
}