import * as React from 'react';
import { Text, View } from 'react-native';
import { FontAwesome } from 'react-native-vector-icons';

export default function LocationTracker() {
  return (
    <View style={{ flex: 1, backgroundColor: 'lightblue', justifyContent: 'center', alignItems: 'center'}}>
      <Text>Location Tracker!</Text>
    </View>
  )
}